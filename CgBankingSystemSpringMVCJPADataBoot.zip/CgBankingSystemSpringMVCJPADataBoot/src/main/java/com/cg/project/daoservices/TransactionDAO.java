package com.cg.project.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.project.beans.Transaction;
import com.cg.project.exceptions.AccountNotFoundException;
import com.cg.project.exceptions.BankingServicesDownException;

public interface TransactionDAO extends JpaRepository<Transaction, Integer> {
	@Query("SELECT t FROM Transaction t WHERE t.account.accountNo=:accountNo")
	public List<Transaction> getAccountAllTransaction(@Param("accountNo") int accountNo);
			
}
