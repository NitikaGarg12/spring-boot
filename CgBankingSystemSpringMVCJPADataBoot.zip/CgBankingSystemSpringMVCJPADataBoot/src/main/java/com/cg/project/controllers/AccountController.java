package com.cg.project.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;
import com.cg.project.exceptions.AccountBlockedException;
import com.cg.project.exceptions.AccountNotFoundException;
import com.cg.project.exceptions.BankingServicesDownException;
import com.cg.project.exceptions.InsufficientAmountException;
import com.cg.project.exceptions.InvalidAccountTypeException;
import com.cg.project.exceptions.InvalidAmountException;
import com.cg.project.exceptions.InvalidPinNumberException;
import com.cg.project.services.BankingServices;

@Controller
public class AccountController {
	@Autowired
	private BankingServices bankingServices;
	@RequestMapping("/registerAccount")
	public ModelAndView registerAccountAction(@Valid @ModelAttribute Account account,
			BindingResult result) throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException {
		
		if(result.hasErrors())
			return new ModelAndView("registrationPage");
		account=bankingServices.openAccount(account);
		return new ModelAndView("registrationSuccessPage","account",account);
	}

	@RequestMapping("/depositMoney")
	public ModelAndView depositAction(@Valid @ModelAttribute Account account, BindingResult result) throws AccountNotFoundException,BankingServicesDownException, AccountBlockedException{
		ModelAndView model = new ModelAndView("homePage");
		account=bankingServices.depositAmount(account.getAccountNo(), account.getTransactions().get(0).getAmount());
		model.addObject("account", account);
		model.addObject("message", "Account deposit successful!");
		return model;
	}
	
	@RequestMapping("/withdrawMoney")
	public ModelAndView withdrawAction(@Valid @ModelAttribute Account account, BindingResult result) throws AccountNotFoundException,BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		ModelAndView model = new ModelAndView("homePage");
		account=bankingServices.withdrawAmount(account.getAccountNo(), account.getTransactions().get(0).getAmount(), account.getPinNumber());
		model.addObject("account", account);
		model.addObject("successMessage", "Account withdraw successful!");
		return model;
	}
	
	@RequestMapping("/fundTransferring")
	public ModelAndView fundTransferAction(@Valid @ModelAttribute Account account, @RequestParam("accountTo") int accountTo, @RequestParam("amount") float amount, BindingResult result) throws AccountNotFoundException,BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		ModelAndView model = new ModelAndView("fundTransferPage");
		account=bankingServices.fundTransfer(accountTo, account.getAccountNo(), amount, account.getPinNumber());
		model.addObject("account", account);
		model.addObject("message", "Fund Transfer successful!");
		return model;
	}
	
	@RequestMapping("/accountDetails")
	public ModelAndView getAccountDetailsAccountAction(@ModelAttribute Account account) throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException {
		ModelAndView model = new ModelAndView("displayAccountDetails");
		account=bankingServices.getAccountDetails(account.getAccountNo());
		model.addObject("account", account);
		return model;
	}
	
	@RequestMapping("/allAccountDetails")
	public ModelAndView getAllAccountDetailsAccountAction(@ModelAttribute Account account) throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException {
		ModelAndView model = new ModelAndView("displayAllAccountDetails");
		List<Account>accounts=bankingServices.getAllAccountDetails();
		model.addObject("accounts", accounts);
		return model;
	}
	
	@RequestMapping("/accountStatus")
	public ModelAndView getAccounStatusAction(@ModelAttribute Account account) throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		ModelAndView model = new ModelAndView("accountStatusPage");
		account=bankingServices.accountStatus(account.getAccountNo());
		model.addObject("account", account);
		model.addObject("message", account.getStatus());
		return model;
	}
	
	@RequestMapping("/updatePin")
	public ModelAndView changePinAction(@Valid @ModelAttribute Account account, @RequestParam("newPinNumber") int newPinNumber, BindingResult result) throws AccountNotFoundException,BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		ModelAndView model = new ModelAndView("changePinPage");
		bankingServices.changeAccountPin(account.getAccountNo(), newPinNumber);
		model.addObject("account", account);
		model.addObject("message", "Pin Changed");
		return model;
	}
	
	@RequestMapping("/accountUnblock")
	public ModelAndView accountUnblockAction(@Valid @ModelAttribute Account account, BindingResult result) throws AccountNotFoundException,BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		ModelAndView model = new ModelAndView("unblockAccountPage");
		bankingServices.unblockAccount(account.getAccountNo());
		model.addObject("account", account);
		model.addObject("message", "Account Unblocked");
		return model;
	}
	
	@RequestMapping("/accountDeactivate")
	public ModelAndView accountDeactivateAction(@Valid @ModelAttribute Account account, BindingResult result) throws AccountNotFoundException,BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		ModelAndView model = new ModelAndView("deactivateAccountPage");
		bankingServices.deactivateAccount(account.getAccountNo());
		model.addObject("message", "Account Deactivated");
		return model;
	}
	
}
