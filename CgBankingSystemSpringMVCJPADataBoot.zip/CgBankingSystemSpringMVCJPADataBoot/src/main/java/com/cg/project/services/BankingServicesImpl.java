package com.cg.project.services;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;
import com.cg.project.daoservices.AccountDAO;
import com.cg.project.daoservices.TransactionDAO;
import com.cg.project.exceptions.AccountBlockedException;
import com.cg.project.exceptions.AccountNotFoundException;
import com.cg.project.exceptions.BankingServicesDownException;
import com.cg.project.exceptions.InsufficientAmountException;
import com.cg.project.exceptions.InvalidAccountTypeException;
import com.cg.project.exceptions.InvalidAmountException;
import com.cg.project.exceptions.InvalidPinNumberException;
@Component(value="bankingServices")
public class BankingServicesImpl implements BankingServices {
	@Autowired
	private AccountDAO accountDAO;
	@Autowired
	private TransactionDAO transactionDAO;
	
	@Override
	public Account openAccount(Account account)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
			if (!(account.getAccountType().equalsIgnoreCase("Savings") || account.getAccountType().equalsIgnoreCase("Current")))
				throw new InvalidAccountTypeException("Invalid account type. Please select among (Savings / Current) account type.");
			if (account.getAccountBalance()<1000)
				throw new InvalidAmountException("Insufficient initial balance. Minimum balance of Rs. 1000 must be added");
			//Account account = new Account(accountType, initBalance, pinNumber);
			List<Transaction> transactions = new ArrayList<>();
			transactions.add(new Transaction(account.getAccountBalance(), "Deposit", account));
			account.setTransactions(transactions);
			account.setStatus("Active");
			account = accountDAO.save(account);
			transactionDAO.save(new Transaction(account.getAccountBalance(), "Deposit", account));
			if (account == null)	throw new BankingServicesDownException("Banking Services are Down. Please try again later.");
			return account;
	}
	
	
	@Override
	public Account depositAmount(int accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account = accountDAO.findById(accountNo).get();
		if (account == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
		account.setAccountBalance(account.getAccountBalance()+amount);
		accountDAO.save(account);
		transactionDAO.save(new Transaction(account.getAccountBalance(), "Deposit", account));
		return account; 	
	}

	
	@Override
	public Account withdrawAmount(int accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
			Account account = accountDAO.findById(accountNo).get();
			if (account == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			//if (account.getStatus().equalsIgnoreCase("Blocked")) throw new AccountBlockedException("The account is blocked. Please contact the customer care to unblock the account");
			if (account.getPinNumber()!=pinNumber)		throw new InvalidPinNumberException("The pin entered is invalid. Please enter a valid pin");
			if (account.getAccountBalance()-amount<1000)	throw new InsufficientAmountException("The transaction got failed due to insufficient balance in the account.");
			account.setAccountBalance(account.getAccountBalance()-amount);
			accountDAO.save(account);
			transactionDAO.save(new Transaction(account.getAccountBalance(),"Withdraw",account));
			return account;
	}

	@Override
	public Account fundTransfer(int accountNoTo, int accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
			if (accountDAO.findById(accountNoTo)==null)	throw new AccountNotFoundException("The Receipent's Account does not exists");
			if (accountDAO.findById(accountNoFrom)==null)	throw new AccountNotFoundException("The Sender Account does not exists");
			//if (accountDAO.fetchAccountStatus(accountNoFrom).getStatus().equalsIgnoreCase("Blocked"))	throw new AccountBlockedException("The sender account is blocked.");
			Account account = accountDAO.findById(accountNoFrom).get();
			if (account.getAccountBalance()-transferAmount<1000)	throw new InsufficientAmountException("The transaction got failed due to insufficient balance in the account.");
			withdrawAmount(accountNoFrom, transferAmount, pinNumber);
	     	depositAmount(accountNoTo, transferAmount);
			return account;
	}

	@Override
	public Account getAccountDetails(int accountNo) throws AccountNotFoundException, BankingServicesDownException {
			Account account = accountDAO.findById(accountNo).get();
			List<Transaction> transactions = transactionDAO.findAll();
			account.setTransactions(transactions);
			if (account == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			return account;
	}

	

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException, AccountNotFoundException {
		List<Account> accounts = accountDAO.findAll();
		for (Account account : accounts) {
			account.setTransactions(getAccountAllTransaction(account.getAccountNo()));
		}
		 
		if (accounts == null) throw new AccountNotFoundException("No Accounts Found!");
		return accounts;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
			return transactionDAO.getAccountAllTransaction(accountNo);
	}

	@Override
	public Account accountStatus(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account =  accountDAO.findById(accountNo).get();
		//	Account account =  accountDAO.fetchAccountStatus(accountNo);
			if (account == null) throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			//if (account.getStatus().equalsIgnoreCase("Blocked")) throw new AccountBlockedException("The account is blocked. Please contact the customer care to unblock the account");
			return account;
	}
	
	@Override
	public Account changeAccountPin(int accountNo, int pinNumber) throws AccountNotFoundException, BankingServicesDownException{
			Account account =  accountDAO.findById(accountNo).get();
			account.setPinNumber(pinNumber);
			accountDAO.save(account);
			if (account==null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");	
			return account;
	}

	@Override
	public Account unblockAccount(int accountNo)
			throws AccountNotFoundException, BankingServicesDownException {
		Account account =  accountDAO.findById(accountNo).get();
		account.setStatus("Active");
		accountDAO.save(account);
			if (account==null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			return account;
	}

	@Override
	public Account deactivateAccount(int accountNo)
			throws AccountNotFoundException, BankingServicesDownException {
		Account account =  accountDAO.findById(accountNo).get();
			if (account== null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			accountDAO.deleteById(accountNo);
			return null;

	}
}
