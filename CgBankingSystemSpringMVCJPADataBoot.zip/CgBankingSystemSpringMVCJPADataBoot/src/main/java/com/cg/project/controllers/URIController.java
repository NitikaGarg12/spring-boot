package com.cg.project.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;


@Controller
public class URIController {
	Account account;

	
	@RequestMapping("/")
	public String getIndexPage() {
		return "homePage";
	}

	@RequestMapping("/registration")
	public String getRegistrationPage() {
		return "registrationPage";
	}
	@RequestMapping("/home")
	public String getHomePage() {
		return "homePage";
	}

	@RequestMapping("/deposit")
	public String getDepositPage() {
		return "depositPage";
	}

	@RequestMapping("/withdraw")
	public String getWithdrawPage() {
		return "withdrawPage";
	}
	
	@RequestMapping("/fundTransfer")
	public String getfundTransferPage() {
		return "fundTransferPage";
	}
	
	@RequestMapping("/getSpecificAccountDetails")
	public String getAccountDetailsPage() {
		return "getAccountDetailsPage";
	}
	
	@RequestMapping("/getAllAccountDetails")
	public String getAllAccountDetailsPage() {
		return "getAllAccountDetailsPage";
	}
	
	@RequestMapping("/getAccountStatus")
	public String getAccountStatusPage() {
		return "accountStatusPage";
	}
	
	@RequestMapping("/changePin")
	public String getPinChangePage() {
		return "changePinPage";
	}
	
	@RequestMapping("/unblockAccount")
	public String getunblockAccountPage() {
		return "unblockAccountPage";
	}

	@RequestMapping("/deactivateAccount")
	public String getdeactivateAccountPage() {
		return "deactivateAccountPage";
	}

	@ModelAttribute
	public Account getAccount() {
		account=new Account();
		return account;
	}
	
}
