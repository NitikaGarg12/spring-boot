package com.cg.project.services;
import java.util.List;

import org.jboss.logging.Param;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;
import com.cg.project.exceptions.AccountBlockedException;
import com.cg.project.exceptions.AccountNotFoundException;
import com.cg.project.exceptions.BankingServicesDownException;
import com.cg.project.exceptions.InsufficientAmountException;
import com.cg.project.exceptions.InvalidAccountTypeException;
import com.cg.project.exceptions.InvalidAmountException;
import com.cg.project.exceptions.InvalidPinNumberException;

public interface BankingServices {
	Account openAccount(Account account)
			throws InvalidAmountException,InvalidAccountTypeException,BankingServicesDownException;
	
	Account depositAmount(int accountNo, float amount)
			throws AccountNotFoundException,BankingServicesDownException, AccountBlockedException;

	Account withdrawAmount(int accountNo,float amount,int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException ,AccountBlockedException;

	Account fundTransfer(int accountNoTo,int accountNoFrom,float transferAmount,int pinNumber)
			throws InsufficientAmountException,AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException;

	Account getAccountDetails(int accountNo)
			throws  AccountNotFoundException,BankingServicesDownException;

	List<Account> getAllAccountDetails()
			throws BankingServicesDownException, AccountNotFoundException;

	List<Transaction> getAccountAllTransaction(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException;

	 Account accountStatus(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException;
	
	Account changeAccountPin(int accountNo,int pinNumber) 
			throws AccountNotFoundException, BankingServicesDownException;
	
	Account unblockAccount(int accountNo)
			throws AccountNotFoundException, BankingServicesDownException;

	Account deactivateAccount(int accountNo)
			throws AccountNotFoundException, BankingServicesDownException;
}