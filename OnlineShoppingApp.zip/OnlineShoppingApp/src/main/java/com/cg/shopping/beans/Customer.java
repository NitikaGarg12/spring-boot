package com.cg.shopping.beans;


import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator="customerIdGenerator")
	@SequenceGenerator(name="customerIdGenerator",initialValue=1001,allocationSize=0)
	private int customerId;
	private String firstName;
	private String lastName;
	private long mobileNo;
	private String emailId;
	@Embedded
	private Address address;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="customer",orphanRemoval=true)
	@MapKey
	private Map<Integer,Order> order;
}
