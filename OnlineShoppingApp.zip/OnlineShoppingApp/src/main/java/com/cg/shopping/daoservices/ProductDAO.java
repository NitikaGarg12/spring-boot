package com.cg.shopping.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.shopping.beans.Product;

public interface ProductDAO extends JpaRepository<Product, Integer> {

}
