package com.cg.shopping.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator="productIdGenerator")
	@SequenceGenerator(name="productIdGenerator",initialValue=11,allocationSize=0)
	private int productId;
	private String productName;
	private String manufacturedDate;
	private String productDescription;
	private int stock;
	private int quantity;
	private double price;

}
