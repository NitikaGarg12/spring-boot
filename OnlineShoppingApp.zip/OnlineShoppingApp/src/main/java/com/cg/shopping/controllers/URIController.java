package com.cg.shopping.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.shopping.beans.Customer;
import com.cg.shopping.beans.Order;
import com.cg.shopping.beans.Product;

@Controller
public class URIController {
	Customer customer;
	Product product;
	Order order;
	@RequestMapping("/")
	public String getIndexPage() {
		return "loginPage";
	}
	@RequestMapping("/index")
	public String getHomePage() {
		return "indexPage";
	}
	@RequestMapping("/login")
	public String getLoginPage() {
		return "loginPage";
	}
	@RequestMapping("/adminIndex")
	public String getAdminIndexPage() {
		return "adminIndexPage";
	}
	@RequestMapping("/signUp")
	public String getSignUpPage() {
		return "registrationPage";
	}
	@RequestMapping("/registration")
	public String getRegistrationPage() {
		return "registrationPage";
	}
	@RequestMapping("/addProducts")
	public String getaddProductsPage() {
		return "addProductPage";
	}
	@RequestMapping("/getProductDetails")
	public String getAllProductDetailsPage() {
		return "getAllProductDetailsPage";
	}
	@RequestMapping("/getCustomerDetails")
	public String getCustomerDetailsPage() {
		return "getSpecificCustomerDetailsPage";
	}
	@RequestMapping("/getAllCustomerDetails")
	public String getAllCustomerDetailsPage() {
		return "getAllCustomerDetailsPage";
	}
	@RequestMapping("/placeOrder")
	public String placeYourOrderPage() {
		return "placeOrderPage";
	}
	@RequestMapping("/getOrderDetails")
	public String getOrderDetailsPage() {
		return "getSpecificOrderDetailsPage";
	}
	@RequestMapping("/getAllOrderDetails")
	public String getAllOrderDetailsPage() {
		return "getAllOrderDetailsPage";
	}
	@ModelAttribute
	public Customer getCustomer() {
		customer=new Customer();
		return customer;
	}
	@ModelAttribute
	public Product getProduct() {
		product=new Product();
		return product;
	}
	@ModelAttribute
	public Order getOrder() {
		order=new Order();
		return order;
	}
}
