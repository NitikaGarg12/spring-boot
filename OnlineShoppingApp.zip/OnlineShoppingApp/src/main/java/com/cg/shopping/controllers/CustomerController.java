package com.cg.shopping.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.shopping.beans.Customer;
import com.cg.shopping.beans.Order;
import com.cg.shopping.beans.Product;
import com.cg.shopping.exceptions.OnlineServicesDownException;
import com.cg.shopping.exceptions.OrderDetailsNotFoundException;
import com.cg.shopping.services.OnlineServices;

@Controller
public class CustomerController {

	@Autowired
	private OnlineServices onlineServices;
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@ModelAttribute Customer customer, BindingResult result) {
		try {
			if(result.hasErrors()) 
				return new ModelAndView("registrationPage");
			ModelAndView model=new ModelAndView("registrationPage");
			customer=onlineServices.registerCustomer(customer);
			model.addObject("message", "Customer registered successfully. Your customer Id is "+customer.getCustomerId());
			return model;
		} catch (OnlineServicesDownException e) {
			return new ModelAndView("registrationPage","message",e.getStackTrace());
		}
	}
	@RequestMapping("/addProduct")
	public ModelAndView addProductAction(@ModelAttribute Product product, BindingResult result) {
		try {
			if(result.hasErrors())
				return new ModelAndView("addProductPage");
			ModelAndView model=new ModelAndView("addProductPage");
			product=onlineServices.addProductDetails(product);
			model.addObject("message","Your product Id is "+product.getProductId());
			return model;
		} catch (OnlineServicesDownException e) {
			return new ModelAndView("addProductPage","message",e.getStackTrace());
		}
	}
	@RequestMapping("/productCalalog")
	public ModelAndView allProductDetailsAction(@ModelAttribute Product product, BindingResult result) {
		try {
			ModelAndView model=new ModelAndView("getAllProductDetailsPage");
			List<Product> products=onlineServices.getAllProductDetails();
			model.addObject("flag",1);
			model.addObject("products",products);
			return model;
		} catch (OnlineServicesDownException e) {
			return new ModelAndView("getAllProductDetailsPage","message",e.getStackTrace());
		}

	}
	@RequestMapping("/allCustomerDetails")
	public ModelAndView allCustomerDetailsAction(@ModelAttribute Customer customer, BindingResult result) {
		try {
			ModelAndView model=new ModelAndView("getAllCustomerDetailsPage");
			List<Customer> customers=onlineServices.getAllCustomerDetails();
			model.addObject("flag",1);
			model.addObject("customers",customers);
			return model;
		} catch (OnlineServicesDownException e) {
			return new ModelAndView("getAllCustomerDetailsPage","message",e.getStackTrace());
		}
	}
	@RequestMapping("/specificOrderDetails")
	public ModelAndView specificOrderDetailsAction(@RequestParam("customerId") int customerId, @ModelAttribute Order order, BindingResult result) {
		 try {
		ModelAndView model=new ModelAndView("getSpecificOrderDetailsPage");
			order=onlineServices.getSpecificOrderDetails(order.getOrderNo());
			model.addObject("flag",1);
			model.addObject("order",order);
			return model;
		} catch (OnlineServicesDownException | OrderDetailsNotFoundException e) {
			return new ModelAndView("getSpecificOrderDetailsPage","message",e.getStackTrace());
		}
	}
	@RequestMapping("/allOrderDetails")
	public ModelAndView allOrderDetailsAction(@ModelAttribute Customer customer, BindingResult result) {
		try {
		ModelAndView model=new ModelAndView("getAllOrderDetailsPage");
			List<Order> orders=onlineServices.getAllOrderDetails();
			model.addObject("flag",1);
			model.addObject("orders",orders);
			return model;
		} catch (OnlineServicesDownException e) {
			return new ModelAndView("getAllOrderDetailsPage","message",e.getStackTrace());
		}
		
	}
}
