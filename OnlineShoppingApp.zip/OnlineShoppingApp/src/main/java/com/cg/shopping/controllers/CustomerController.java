package com.cg.shopping.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;

import com.cg.shopping.beans.Customer;
import com.cg.shopping.beans.Order;
import com.cg.shopping.beans.Product;
import com.cg.shopping.exceptions.CustomerDetailsNotFoundException;
import com.cg.shopping.exceptions.OnlineServicesDownException;
import com.cg.shopping.exceptions.OrderDetailsNotFoundException;
import com.cg.shopping.exceptions.ProductDetailsNotFoundException;
import com.cg.shopping.services.OnlineServices;

@Controller
public class CustomerController {

	@Autowired
	private OnlineServices onlineServices;
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid @ModelAttribute Customer customer, BindingResult result) {
		try {
			if(result.hasErrors()) 
				return new ModelAndView("registrationPage");
			ModelAndView model=new ModelAndView("registrationPage");
			customer=onlineServices.registerCustomer(customer);
			model.addObject("message", "Customer registered successfully. Your customer Id is "+customer.getCustomerId());
			return model;
		} catch (OnlineServicesDownException e) {
			return new ModelAndView("registrationPage","message",e.getStackTrace());
		}
	}
	@RequestMapping("/addProduct")
	public ModelAndView addProductAction(@Valid @ModelAttribute Product product, BindingResult result,HttpServletRequest request) {
		try {
			if(result.hasErrors())
				return new ModelAndView("addProductPage");
			ModelAndView model=new ModelAndView("addProductPage");
			product=onlineServices.addProductDetails(product);
			model.addObject("message","Your product Id is "+product.getProductId());
			return model;
		} catch (OnlineServicesDownException e) {
			return new ModelAndView("addProductPage","message",e.getStackTrace());
		}
	}
	@RequestMapping("/productCalalog")
	public ModelAndView allProductDetailsAction(@Valid @ModelAttribute Product product, BindingResult result) {
		try {
			ModelAndView model=new ModelAndView("getAllProductDetailsPage");
			List<Product> products=onlineServices.getAllProductDetails();
			model.addObject("flag",1);
			model.addObject("products",products);
			return model;
		} catch (OnlineServicesDownException | ProductDetailsNotFoundException e) {
			return new ModelAndView("getAllProductDetailsPage","message",e.getStackTrace());
		}

	}

	@RequestMapping("/specificCustomerDetails")
	public ModelAndView customerDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) {
		try {
			ModelAndView model = new ModelAndView("getSpecificCustomerDetailsPage");
			customer=onlineServices.getSpecificCustomerDetails(customer.getCustomerId());
			model.addObject("flag",1);
			model.addObject("customer", customer);
			return model;
		} catch (OnlineServicesDownException | CustomerDetailsNotFoundException e) {
			return new ModelAndView("getSpecificCustomerDetailsPage", "message", e.getMessage());
		} 
	}
	@RequestMapping("/allCustomerDetails")
	public ModelAndView allCustomerDetailsAction(@Valid@ModelAttribute Customer customer, BindingResult result) {
		try {
			ModelAndView model=new ModelAndView("getAllCustomerDetailsPage");
			List<Customer> customers=onlineServices.getAllCustomerDetails();
			if(customers.isEmpty())
				return new ModelAndView("getAllCustomerDetailsPage","message","No customer found");
			model.addObject("flag",1);
			model.addObject("customers",customers);
			return model;
		} catch (OnlineServicesDownException | CustomerDetailsNotFoundException e) {
			return new ModelAndView("getAllCustomerDetailsPage","message",e.getStackTrace());
		}
	}
	@RequestMapping("/specificProductDetails")
	public ModelAndView specificProductDetailsAction( @Valid  @ModelAttribute Product product, BindingResult result) {
		try {
			ModelAndView model=new ModelAndView("getSpecificProductDetailsPage");
			product=onlineServices.getSpecificProductDetails(product.getProductId());
			model.addObject("flag",1);
			model.addObject("product",product);
			return model;
		} catch (OnlineServicesDownException | ProductDetailsNotFoundException e) {
			return new ModelAndView("getSpecificProductDetailsPage","message",e.getStackTrace());
		}
	}
	@RequestMapping("/specificOrderDetails")
	public ModelAndView specificOrderDetailsAction( @Valid @RequestParam("customerId") int customerId, @ModelAttribute Order order, BindingResult result) {
		try {
			ModelAndView model=new ModelAndView("getSpecificOrderDetailsPage");
			order=onlineServices.getSpecificOrderDetails(order.getOrderNo());
			model.addObject("flag",1);
			model.addObject("order",order);
			return model;
		} catch (OnlineServicesDownException | OrderDetailsNotFoundException e) {
			return new ModelAndView("getSpecificOrderDetailsPage","message",e.getStackTrace());
		}
	}
	@RequestMapping("/allOrderDetails")
	public ModelAndView allOrderDetailsAction(@Valid @ModelAttribute Customer customer, BindingResult result) {
		try {
			ModelAndView model=new ModelAndView("getAllOrderDetailsPage");
			List<Order> orders=onlineServices.getAllOrderDetails();
			model.addObject("flag",1);
			model.addObject("orders",orders);
			return model;
		} catch (OnlineServicesDownException | OrderDetailsNotFoundException e) {
			return new ModelAndView("getAllOrderDetailsPage","message",e.getStackTrace());
		}

	}
	@RequestMapping("/loginAction")
	public ModelAndView loginAction(@Valid @ModelAttribute Customer customer, BindingResult result) {
		try {
			int userId=customer.getCustomerId();
			String password=customer.getPassword();
			ModelAndView model=new ModelAndView("loginPage");
			customer=onlineServices.getSpecificCustomerDetails(customer.getCustomerId());
			model.addObject("customer",customer);
			if(userId==1021 && password.equals("nitika12"))
				return new ModelAndView("adminIndexPage");
			else
				if(!(customer.getCustomerId()==1005 )&& (customer.getCustomerId()==userId) && customer.getPassword().equals(password))
					return new ModelAndView("indexPage");
				return new ModelAndView("loginPage","message","!!Invalid user Id or password!!");
		} catch (OnlineServicesDownException | CustomerDetailsNotFoundException e) {
			return new ModelAndView("loginPage");
		}
	}
	@RequestMapping("/placeYourOrder")
	public ModelAndView placeOrderAction(@Valid @ModelAttribute Product product, BindingResult result) {
		try {
			ModelAndView model=new ModelAndView("placeOrderPage");
			List<Product> products=onlineServices.getAllProductDetails();
			model.addObject("flag",1);
			model.addObject("products",products);
			return model;
		} catch (OnlineServicesDownException | ProductDetailsNotFoundException e) {
			return new ModelAndView("placeOrderPage","message",e.getStackTrace());
		}

	}
}
