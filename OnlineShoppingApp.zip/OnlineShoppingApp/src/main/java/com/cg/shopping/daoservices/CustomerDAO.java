package com.cg.shopping.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.shopping.beans.Customer;

public interface CustomerDAO extends JpaRepository<Customer, Integer>{

}
