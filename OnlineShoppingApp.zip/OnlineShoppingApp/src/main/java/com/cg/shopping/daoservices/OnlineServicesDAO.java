package com.cg.shopping.daoservices;

public interface OnlineServicesDAO {

}
