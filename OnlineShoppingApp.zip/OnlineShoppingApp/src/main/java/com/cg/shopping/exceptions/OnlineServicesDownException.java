package com.cg.shopping.exceptions;

public class OnlineServicesDownException extends Exception {

	public OnlineServicesDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OnlineServicesDownException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public OnlineServicesDownException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public OnlineServicesDownException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public OnlineServicesDownException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
