package com.cg.shopping.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator="orderIdGenerator")
	@SequenceGenerator(name="orderIdGenerator",initialValue=10001,allocationSize=0)
	private int orderNo;
	private double amount;
	private String orderDate;
	@ManyToOne
	private Customer customer;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="order",orphanRemoval=true)
	@MapKey
	private Map<Integer,Product> product;
	
	
}
