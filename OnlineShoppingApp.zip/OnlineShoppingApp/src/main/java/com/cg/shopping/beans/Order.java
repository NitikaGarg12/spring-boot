package com.cg.shopping.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator="orderIdGenerator")
	@SequenceGenerator(name="orderIdGenerator",initialValue=10001,allocationSize=0)
	private int orderNo;
	private double amount;
	private String orderDate;
	@ManyToOne
	private Customer customer;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="order",orphanRemoval=true)
	@MapKey
	private Map<Integer,Product> product;
	public Order() {}
	public Order(int orderNo, double amount, String orderDate, Customer customer, Map<Integer, Product> product) {
		super();
		this.orderNo = orderNo;
		this.amount = amount;
		this.orderDate = orderDate;
		this.customer = customer;
		this.product = product;
	}
	public int getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Map<Integer, Product> getProduct() {
		return product;
	}
	public void setProduct(Map<Integer, Product> product) {
		this.product = product;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(amount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + ((orderDate == null) ? 0 : orderDate.hashCode());
		result = prime * result + orderNo;
		result = prime * result + ((product == null) ? 0 : product.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (Double.doubleToLongBits(amount) != Double.doubleToLongBits(other.amount))
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (orderDate == null) {
			if (other.orderDate != null)
				return false;
		} else if (!orderDate.equals(other.orderDate))
			return false;
		if (orderNo != other.orderNo)
			return false;
		if (product == null) {
			if (other.product != null)
				return false;
		} else if (!product.equals(other.product))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Order [orderNo=" + orderNo + ", amount=" + amount + ", orderDate=" + orderDate + ", customer="
				+ customer + ", product=" + product + "]";
	}
	
	
	
}
