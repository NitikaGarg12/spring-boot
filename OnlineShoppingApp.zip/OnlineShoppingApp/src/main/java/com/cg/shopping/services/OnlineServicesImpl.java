package com.cg.shopping.services;

import org.springframework.stereotype.Component;

@Component("onlineServices")
public class OnlineServicesImpl implements OnlineServices {
	
}
