package com.cg.shopping.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.shopping.beans.Customer;
import com.cg.shopping.beans.Order;
import com.cg.shopping.beans.Product;
import com.cg.shopping.daoservices.CustomerDAO;
import com.cg.shopping.daoservices.OnlineServicesDAO;
import com.cg.shopping.daoservices.OrderDAO;
import com.cg.shopping.daoservices.ProductDAO;
import com.cg.shopping.exceptions.OnlineServicesDownException;
import com.cg.shopping.exceptions.OrderDetailsNotFoundException;

@Component("onlineServices")
public class OnlineServicesImpl implements OnlineServices {

	@Autowired
	private CustomerDAO customerDAO;
	@Autowired
	private OrderDAO orderDao;
	@Autowired
	private ProductDAO productDAO;

	@Override
	public Customer registerCustomer(Customer customer) throws OnlineServicesDownException {
		return customerDAO.save(customer);
	}

	@Override
	public Product addProductDetails(Product product) throws OnlineServicesDownException {
		return productDAO.save(product);
	}

	@Override
	public List<Product> getAllProductDetails() throws OnlineServicesDownException {
		return productDAO.findAll();
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws OnlineServicesDownException {
		return customerDAO.findAll();
	}

	@Override
	public Order getSpecificOrderDetails(int orderId)
			throws OnlineServicesDownException, OrderDetailsNotFoundException {
		return orderDao.findById(orderId).orElseThrow(()-> new OrderDetailsNotFoundException("Order Details Not Found"));
		
	}

	@Override
	public List<Order> getAllOrderDetails() throws OnlineServicesDownException {
		return orderDao.findAll();
	}
	
}
