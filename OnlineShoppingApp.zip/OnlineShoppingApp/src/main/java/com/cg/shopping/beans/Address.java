package com.cg.shopping.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
	private String city;
	private String state;
	private String pinCode;
}
