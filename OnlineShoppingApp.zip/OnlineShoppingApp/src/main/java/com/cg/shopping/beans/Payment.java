package com.cg.shopping.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Payment {
@Id
@GeneratedValue(strategy=GenerationType.AUTO,generator="paymentIdGenerator")
	private int paymentId;
	private String paymentMedium;
	private Customer customer;
}
