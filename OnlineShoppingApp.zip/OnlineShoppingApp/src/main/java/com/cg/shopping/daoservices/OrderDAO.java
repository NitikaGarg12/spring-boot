package com.cg.shopping.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.shopping.beans.Order;

public interface OrderDAO extends JpaRepository<Order, Integer>{

}
