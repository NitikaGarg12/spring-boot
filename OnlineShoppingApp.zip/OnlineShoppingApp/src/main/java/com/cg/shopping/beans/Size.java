package com.cg.shopping.beans;

public enum Size {
	SMALL,
	MEDIUM,
	LARGE                                                                                                                                                                                                                                                                                                                                                       
}
