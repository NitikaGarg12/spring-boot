package com.cg.shopping.services;

import java.util.List;

import com.cg.shopping.beans.Customer;
import com.cg.shopping.beans.Order;
import com.cg.shopping.beans.Product;
import com.cg.shopping.exceptions.OnlineServicesDownException;
import com.cg.shopping.exceptions.OrderDetailsNotFoundException;

public interface OnlineServices {
	public Customer registerCustomer(Customer customer) throws OnlineServicesDownException;
	public Product addProductDetails(Product product) throws OnlineServicesDownException;
	public List<Product> getAllProductDetails() throws OnlineServicesDownException;
	public List<Customer> getAllCustomerDetails()throws OnlineServicesDownException;
	public Order getSpecificOrderDetails(int orderId)throws OnlineServicesDownException,OrderDetailsNotFoundException;
	public List<Order> getAllOrderDetails() throws OnlineServicesDownException; 
	
}
