package com.cg.shopping.services;

import java.util.List;

import com.cg.shopping.beans.Customer;
import com.cg.shopping.beans.Order;
import com.cg.shopping.beans.Product;
import com.cg.shopping.exceptions.CustomerDetailsNotFoundException;
import com.cg.shopping.exceptions.OnlineServicesDownException;
import com.cg.shopping.exceptions.OrderDetailsNotFoundException;
import com.cg.shopping.exceptions.ProductDetailsNotFoundException;

public interface OnlineServices {
	public Customer registerCustomer(Customer customer) throws OnlineServicesDownException;
	public Product addProductDetails(Product product) throws OnlineServicesDownException;
	public Product getSpecificProductDetails(int productId) throws OnlineServicesDownException,ProductDetailsNotFoundException;
	public List<Product> getAllProductDetails() throws OnlineServicesDownException,ProductDetailsNotFoundException;
	public Customer getSpecificCustomerDetails(int customerId)throws OnlineServicesDownException,CustomerDetailsNotFoundException;
	public List<Customer> getAllCustomerDetails()throws OnlineServicesDownException, CustomerDetailsNotFoundException;
	public Order getSpecificOrderDetails(int orderId)throws OnlineServicesDownException,OrderDetailsNotFoundException;
	public List<Order> getAllOrderDetails() throws OnlineServicesDownException,OrderDetailsNotFoundException; 
}
