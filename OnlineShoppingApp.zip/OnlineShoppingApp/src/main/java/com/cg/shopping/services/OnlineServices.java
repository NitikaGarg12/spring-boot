package com.cg.shopping.services;

public interface OnlineServices {

}
