package com.cg.payroll.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage {
	
	@FindBy(how=How.XPATH,xpath="/html/body/div/form/table/tbody/tr/td/a")
	private WebElement link;
	
	public LoginPage() {}
	
	public void clickSignIn() {
		link.click();
	}	
}
