package com.cg.payroll.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPage {
	@FindBy(how=How.XPATH,xpath="//*[@id=\"firstName\"]")
	private WebElement firstName;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"lastName\"]")
	private WebElement lastName;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"department\"]")
	private WebElement department;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"emailId\"]")
	private WebElement emailId;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"designation\"]")
	private WebElement designation;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"bankDetails.bankName\"]")
	private WebElement bankName;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"salary.epf\"]")
	private WebElement epf;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"salary.companyPF\"]")
	private WebElement companyPF;
	@FindBy(how=How.XPATH,xpath="/html/body/div/table/tbody/tr[9]/td/input")
	private WebElement button;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"js-flash-container\"]/div/div")
	private WebElement actualErrorMessage;
	
	public RegistrationPage() {}
	
	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getDepartment() {
		return department.getAttribute("value");
	}

	public void setDepartment(String department) {
		this.department.sendKeys(department);
	}

	public String getEmailId() {
		return emailId.getAttribute("value");
	}

	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}

	public String getDesignation() {
		return designation.getAttribute("value");
	}

	public void setDesignation(String designation) {
		this.designation.sendKeys(designation);
	}

	public String getBankName() {
		return bankName.getAttribute("value");
	}

	public void setBankName(String bankName) {
		this.bankName.sendKeys(bankName);
	}

	public String getEpf() {
		return epf.getAttribute("value");
	
	}

	public void setEpf(String epf) {
		this.epf.clear();
		this.epf.sendKeys(epf);
	}


	public String getCompanyPF() {
		return companyPF.getAttribute("value");
	}

	public void setCompanyPF(String companyPF) {
		this.companyPF.clear();
		this.companyPF.sendKeys(companyPF);
	}
		


	public void setActualErrorMessage(WebElement actualErrorMessage) {
		this.actualErrorMessage = actualErrorMessage;
	}

	
	public String getActualErrorMessage() {
		return actualErrorMessage.getText();
	}
	public void clickSignIn() {
		button.click();
	}	
}
