package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.beans.Salary;
import com.cg.payroll.pagebeans.LoginPage;
import com.cg.payroll.pagebeans.RegistrationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {
	private WebDriver driver;
	private RegistrationPage registrationPage;
	@Given("^Associate is on registration Page$")
	public void associate_is_on_registration_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\nitika\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/registration");
		registrationPage=PageFactory.initElements(driver, RegistrationPage.class);
	}

	@When("^Associate enter his correct credentials$")
	public void associate_enter_his_correct_credentials() throws Throwable {
		
		registrationPage.setFirstName("Nitika");
		registrationPage.setLastName("Garg");
		registrationPage.setDepartment("cse");
		registrationPage.setEmailId("nini.garg@gmail.com");
		registrationPage.setDesignation("senior analyst");
		registrationPage.setBankName("hdfc");
		registrationPage.setEpf("200");
		registrationPage.setCompanyPF("500");
		registrationPage.clickSignIn();
		
	}

	@Then("^Associate is redirected to registration success page$")
	public void associate_is_redirected_to_registration_success_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration Successful";
		Assert.assertEquals(expectedTitle, actualTitle);
		
	}

}
