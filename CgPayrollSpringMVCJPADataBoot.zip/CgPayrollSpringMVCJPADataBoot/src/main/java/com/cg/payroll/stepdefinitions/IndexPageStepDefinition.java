package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.pagebeans.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class IndexPageStepDefinition {
	private LoginPage loginPage;
	private WebDriver driver;
	@Given("^Associate is on index Page$")
	public void associate_is_on_index_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\nitika\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/");
		loginPage=PageFactory.initElements(driver, LoginPage.class);
	}

	@When("^Associate click on registration link$")
	public void associate_click_on_registration_link() throws Throwable {
		loginPage.clickSignIn();
	}

	@Then("^Associate is redirected to registration page$")
	public void associate_is_redirected_to_registration_page() throws Throwable {
		String actualTitle=driver.getTitle();
		System.out.println(actualTitle);
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

}
