/*package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.GetCustomerPostpaidAccountPlanDetailsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetCustomerPostpaidAccountPlanDetailsStepDefinition {
	private WebDriver driver;
	private GetCustomerPostpaidAccountPlanDetailsPage getCustomerPostpaidAccountPlanDetailsPage;
	@Given("^User is on getCustomerPostPaidAccountPlanDetailsPage Page$")
	public void user_is_on_getCustomerPostPaidAccountPlanDetailsPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\nitika\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/getCustomerPostPaidAccountPlanDetails");
		getCustomerPostpaidAccountPlanDetailsPage=PageFactory.initElements(driver, GetCustomerPostpaidAccountPlanDetailsPage.class);
	}

	@When("^User enter his correct details and clicks on submit button$")
	public void user_enter_his_correct_details_and_clicks_on_submit_button() throws Throwable {
	   getCustomerPostpaidAccountPlanDetailsPage.setCustomerID("20001");
	   getCustomerPostpaidAccountPlanDetailsPage.setMobileNo("999999999");
	   getCustomerPostpaidAccountPlanDetailsPage.clickSignIn();
	}

	@Then("^User is redirected to getCustomerPostPaidAccountPlanDetailsPage page and details gets displayed$")
	public void user_is_redirected_to_getCustomerPostPaidAccountPlanDetailsPage_page_and_details_gets_displayed() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Get Customer Postpaid Account Plan Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
*/