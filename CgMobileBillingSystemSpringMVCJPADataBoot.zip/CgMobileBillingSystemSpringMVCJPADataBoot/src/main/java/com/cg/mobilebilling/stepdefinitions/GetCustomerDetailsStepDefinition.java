package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.AddPlansPage;
import com.cg.mobilebilling.pagebeans.GetCustomerDetails;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetCustomerDetailsStepDefinition {
	private GetCustomerDetails getCustomerDetails;
	private WebDriver driver;
	@Given("^User is on getCustomerDetailsPage Page$")
	public void user_is_on_getCustomerDetailsPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\nitika\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/getCustomerDetails");
		getCustomerDetails=PageFactory.initElements(driver, GetCustomerDetails.class);
	}
	@When("^User enter correct details and click on submit button$")
	public void user_enter_correct_details_and_click_on_submit_button() throws Throwable {
	 getCustomerDetails.setCustomerID("20001");
	 getCustomerDetails.clickSignIn();
	}

	@Then("^User is redirected to getCustomerDetailsPage page and details gets displayed$")
	public void user_is_redirected_to_getCustomerDetailsPage_page_and_details_gets_displayed() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Get Customer Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}


}
