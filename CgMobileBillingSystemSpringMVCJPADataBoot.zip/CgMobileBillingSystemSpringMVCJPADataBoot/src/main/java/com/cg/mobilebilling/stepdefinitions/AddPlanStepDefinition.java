/*package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.AddPlansPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddPlanStepDefinition {
	private AddPlansPage addPlansPage;
	private WebDriver driver;
	@Given("^User is on addPlansPage Page$")
	public void user_is_on_addPlansPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\nitika\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/addPlans");
		addPlansPage=PageFactory.initElements(driver, AddPlansPage.class);
	}

	@When("^User enter the details and click on submit button$")
	public void user_enter_the_details_and_click_on_submit_button() throws Throwable {
		addPlansPage.setMonthlyRental("1000");
		addPlansPage.setFreeLocalCalls("500");
		addPlansPage.setFreeStdCalls("500");
		addPlansPage.setFreeLocalSMS("200");
		addPlansPage.setFreeStdSMS("200");
		addPlansPage.setFreeInternetDataUsageUnits("5");
		addPlansPage.setLocalCallRate("10");
		addPlansPage.setStdCallRate("10");
		addPlansPage.setLocalSMSRate("5");
		addPlansPage.setStdSMSRate("5");
		addPlansPage.setInternetDataUsageRate("2");
		addPlansPage.setPlanCircle("Pune");
		addPlansPage.setPlanName("golden");
		addPlansPage.clickSignIn();
		
	  
	}

	@Then("^User is redirected to addPlansPage page and message gets displayed$")
	public void user_is_redirected_to_addPlansPage_page_and_message_gets_displayed() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Add plans";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
	

}
*/