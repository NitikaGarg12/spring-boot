package com.cg.mobilebilling.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.RegistrationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {
	private RegistrationPage registrationPage;
	private WebDriver driver;
	@Given("^User is on registration Page$")
	public void user_is_on_registration_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\nitika\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/");
		registrationPage=PageFactory.initElements(driver, RegistrationPage.class);
	}

	@When("^User enter his correct details and click on submit button$")
	public void user_enter_his_correct_details_and_click_on_submit_button() throws Throwable {
	    registrationPage.setFirstName("Nitika");
	    registrationPage.setLastName("Garg");
	    registrationPage.setEmailID("nini.garg@gmail.com");
	    registrationPage.setDateOfBirth("12/12/1993");
	    registrationPage.setCity("Bathinda");
	    registrationPage.setState("Punjab");
	    registrationPage.setPinCode("151001");
	    registrationPage.clickSignIn();
	}

	@Then("^User is redirected to registration page and message gets displayed$")
	public void user_is_redirected_to_registration_page_and_message_gets_displayed() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^User click on home page button$")
	public void user_click_on_home_page_button() throws Throwable {
		 registrationPage.clickHome();
	}

	@Then("^User is redirected to home page$")
	public void user_is_redirected_to_home_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="WebApp1";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

}
