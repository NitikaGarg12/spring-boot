package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.OpenPostpaidMobileAccount;
import com.cg.mobilebilling.pagebeans.RegistrationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OpenPostpaidMobileAccountStepDefinition {
	private OpenPostpaidMobileAccount openPostpaidMobileAccount;
	private WebDriver driver;

	@Given("^User is on openPostpaidMobileAccountPage Page$")
	public void user_is_on_openPostpaidMobileAccountPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\nitika\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/openPostpaidMobileAccount");
		openPostpaidMobileAccount=PageFactory.initElements(driver, OpenPostpaidMobileAccount.class);
	}

	@When("^User enter his correct credentials and click on submit button$")
	public void user_enter_his_correct_credentials_and_click_on_submit_button() throws Throwable {
		openPostpaidMobileAccount.setCustomerID("20001");
		openPostpaidMobileAccount.setPlanID("1001");
		openPostpaidMobileAccount.clickSignIn();
	
	}

	@Then("^User is redirected to openPostpaidMobileAccountPage page and message gets displayed$")
	public void user_is_redirected_to_openPostpaidMobileAccountPage_page_and_message_gets_displayed() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Open postpaid account";
		Assert.assertEquals(expectedTitle, actualTitle);
	}


}
