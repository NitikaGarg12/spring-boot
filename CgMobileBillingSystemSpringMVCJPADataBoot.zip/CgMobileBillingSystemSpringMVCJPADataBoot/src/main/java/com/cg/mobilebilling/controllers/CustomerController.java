package com.cg.mobilebilling.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;


@Controller
public class CustomerController {
	@Autowired
	private BillingServices billingServices;
	
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		if(result.hasErrors())
			return new ModelAndView("registrationPage");
		ModelAndView model = new ModelAndView("registrationPage");
		customer = billingServices.acceptCustomerDetails(customer.getFirstName(), customer.getLastName(), customer.getEmailID(), customer.getDateOfBirth(), customer.getBillingAddress().getCity(),customer.getBillingAddress().getState(), customer.getBillingAddress().getPinCode());
		model.addObject("message", "Customer details added successfully. Your customer Id is: "+customer.getCustomerID());
		return model;
	}
	
	@RequestMapping("planAllDetails")
	public ModelAndView planAllDetailsAction(@Valid @ModelAttribute Plan plan,
			BindingResult result) {
		try {
		ModelAndView model=new ModelAndView("getPlanAllDetailsPage");
		List<Plan> plans=billingServices.getPlanAllDetails();
		model.addObject("plans", plans);
		return model;
		} catch (BillingServicesDownException e) {
			return new ModelAndView("getPlanAllDetailsPage", "message", e.getMessage());
		}
	
				
			}
	
	@RequestMapping("savePlan")
	public ModelAndView planDetailsAction(@Valid @ModelAttribute Plan plan,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("addPlansPage");
		plan=billingServices.acceptPlanDetails(plan);
		model.addObject("message", "Plan details added successfully.  Plan Id is: "+plan.getPlanID());
				return model;
				
			}
	
	@RequestMapping("openPostpaidAccount")
	public ModelAndView openPostpaidAccountAction( @Valid @RequestParam("planID") int planID,@ModelAttribute Customer customer,
			BindingResult result)  {
		try {
		
			long mobileNo=billingServices.openPostpaidMobileAccount(customer.getCustomerID(), planID);
			ModelAndView model = new ModelAndView("openPostpaidMobileAccountPage","mobileNo",mobileNo);
		model.addObject("message", "Your postpaid account for mobileNo "+mobileNo+" is successfully opened");
			return model;
		} catch (PlanDetailsNotFoundException | CustomerDetailsNotFoundException | BillingServicesDownException e) {
			return new ModelAndView("openPostpaidMobileAccountPage", "message", e.getMessage());
		}
			
				
			}
	
	@RequestMapping("customerDetails")
	public ModelAndView customerDetailsAction(@Valid@ModelAttribute Customer customer,
			BindingResult result) {
		try {
			ModelAndView model = new ModelAndView("getCustomerDetailsPage");
			customer=billingServices.getCustomerDetails(customer.getCustomerID());
			model.addObject("flag",1);
			model.addObject("customer", customer);
			return model;
		} catch (CustomerDetailsNotFoundException | BillingServicesDownException e) {
			return new ModelAndView("getCustomerDetailsPage", "message", e.getMessage());
		} 
	}
	
	@RequestMapping("/allCustomerDetails")
	public ModelAndView allCustomerDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) {
		try {
		ModelAndView model = new ModelAndView("getAllCustomerDetailsPage");
		List<Customer> customers;
			customers = billingServices.getAllCustomerDetails();
			model.addObject("flag",1);
			model.addObject("customers", customers);
			return model;
		} catch (BillingServicesDownException e) {
			return new ModelAndView("getAllCustomerDetailsPage", "message", e.getMessage());
		}
		
			}
	
	@RequestMapping("postpaidAccountDetails")
	public ModelAndView postpaidAccountDetailsAction(@Valid @RequestParam("mobileNo") long mobileNo, @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		try {
		ModelAndView model = new ModelAndView("getPostPaidAccountDetailsPage");
			PostpaidAccount postpaidAccount=billingServices.getPostPaidAccountDetails(customer.getCustomerID(), mobileNo);
			model.addObject("flag",1);
			model.addObject("postpaidAccount",postpaidAccount);
			return model;
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException e) {
			return new ModelAndView("getPostPaidAccountDetailsPage", "message", e.getMessage());
		}
		
				
			}
	
	
	@RequestMapping("deleteCustomerAccount")
	public ModelAndView deleteCustomerAccountAction(@Valid @ModelAttribute Customer customer,
			BindingResult result)  {
		try {
		ModelAndView model = new ModelAndView("deleteCustomerPage");
			billingServices.deleteCustomer(customer.getCustomerID());
			model.addObject("message", "Customer Account deleted");
			return model;
		} catch (BillingServicesDownException | CustomerDetailsNotFoundException e) {
			return new ModelAndView("deleteCustomerPage", "message", e.getMessage());
		}
			}
	
	/*@RequestMapping("deletePostpaidAccount")
	public ModelAndView deletePostpaidAccountAction(@Valid @ModelAttribute Customer customer,
			BindingResult result)  {
		try {
		   ModelAndView model = new ModelAndView("closeCustomerPostPaidAccountPage");
			billingServices.closeCustomerPostPaidAccount(customer.getCustomerID(),customer.getPostpaidAccounts().);
			model.addObject("message", "Customer's PostPaid Account deleted");
			return model;
		} catch (BillingServicesDownException | CustomerDetailsNotFoundException e) {
			return new ModelAndView("closeCustomerPostPaidAccountPage", "message", e.getMessage());
		}		
			}*/
	/*
	@RequestMapping("customerPostPaidAccountPlanDetails")
	public ModelAndView customerPostPaidAccountPlanDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("getCustomerPostPaidAccountPlanDetailsPage");
				return null;
				
			}*/
	
	@RequestMapping("planChange")
	public ModelAndView planChangeAction(@Valid @RequestParam("mobileNo") long mobileNo, @RequestParam("planID") int planID,@ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		try {
		ModelAndView model = new ModelAndView("changePlanPage");
			billingServices.changePlan(customer.getCustomerID(), mobileNo, planID);
			model.addObject("message","Your plan is successfully changed");
			return model;
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | PlanDetailsNotFoundException e) {
			return new ModelAndView("changePlanPage", "message", e.getMessage());
		}
				
				
			}
	/*
	@RequestMapping("mobileBillDetails")
	public ModelAndView mobileBillDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("getMobileBillDetailsPage");
				return null;
				
			}*/
	
	@RequestMapping("customerAllPostPaidAccountDetails")
	public ModelAndView customerAllPostPaidAccountDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		try {
			ModelAndView model = new ModelAndView("getCustomerAllPostpaidAccountsDetailsPage");
			List<PostpaidAccount> postpaidAccounts= billingServices.getCustomerAllPostpaidAccountsDetails(customer.getCustomerID());
			model.addObject("flag",1);
			model.addObject("postpaidAccounts", postpaidAccounts);
			return model;
		} catch (CustomerDetailsNotFoundException e) {
			return new ModelAndView("getCustomerAllPostpaidAccountsDetailsPage", "message", e.getMessage());
		}
		
				
			}
/*	
	@RequestMapping("generateMonthlyBill")
	public ModelAndView generateMonthlyMobileAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("generateMonthlyMobileBillPage");
				return null;
				
			}*/
}
