package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CloseCustomerPostPaidAccountPage {
	@FindBy(how=How.ID,id="customerID")
	private WebElement customerID;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"customer\"]/table/tbody/tr[2]/td[2]/input")
	private WebElement mobileNo;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"customer\"]/input")
	private WebElement button1;
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/div/form/input")
	private WebElement button2;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]")
	private WebElement actualMessage;
	public CloseCustomerPostPaidAccountPage() {}
	public String getCustomerID() {
		return customerID.getAttribute("value");
	}
	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);
	}
	public String getMobileNo() {
		return mobileNo.getAttribute("value");
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}
	public String getActualMessage() {
		return actualMessage.getText();
	}
	public void setActualMessage(WebElement actualMessage) {
		this.actualMessage = actualMessage;
	}
	public void clickSignIn() {
		button1.click();
	}	
	public void clickHome() {
		button2.click();
	}	
}
