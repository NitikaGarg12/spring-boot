package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPage {
	@FindBy(how=How.ID,id="firstName")
	private WebElement firstName;
	@FindBy(how=How.ID,id="lastName")
	private WebElement lastName;
	@FindBy(how=How.ID,id="emailID")
	private WebElement emailID;
	@FindBy(how=How.ID,id="dateOfBirth")
	private WebElement dateOfBirth;
	@FindBy(how=How.ID,id="billingAddress.city")
	private WebElement city;
	@FindBy(how=How.ID,id="billingAddress.state")
	private WebElement state;
	@FindBy(how=How.ID,id="billingAddress.pinCode")
	private WebElement pinCode;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"customer\"]/input")
	private WebElement button1;
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/div/form/input")
	private WebElement button2;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]")
	private WebElement actualMessage;
	public RegistrationPage() {}
	public String getFirstName() {
		return firstName.getAttribute("value");
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public String getLastName() {
		return lastName.getAttribute("value");
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	public String getEmailID() {
		return emailID.getAttribute("value");
	}
	public void setEmailID(String emailID) {
		this.emailID.sendKeys(emailID);
	}
	public String getDateOfBirth() {
		return dateOfBirth.getAttribute("value");
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth.sendKeys(dateOfBirth);
	}
	public String getCity() {
		return city.getAttribute("value");
	}
	public void setCity(String city) {
		this.city.sendKeys(city);
	}
	public String getState() {
		return state.getAttribute("value");
	}
	public void setState(String state) {
		this.state.sendKeys(state);
	}
	public String getPinCode() {
		return pinCode.getAttribute("value");
	}
	public void setPinCode(String pinCode) {
		this.pinCode.sendKeys(pinCode);
	}
	public void clickSignIn() {
		button1.click();
	}	
	public void clickHome() {
		button2.click();
	}	
	
	public String getActualMessage() {
		return actualMessage.getText();
	}
	public void setActualMessage(WebElement actualMessage) {
		this.actualMessage = actualMessage;
	}
	
	
}
