package com.cg.mobilebilling.pagebeans;

public class GetMobileBillDetailsPage {

}
