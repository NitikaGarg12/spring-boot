package com.cg.mobilebilling.test;

import static org.junit.Assert.*;
import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.cg.mobilebilling.daoservices.BillingServiceDAO;
import com.cg.mobilebilling.daoservices.CustomerDAO;
import com.cg.mobilebilling.daoservices.PlanDetailsDAO;
import com.cg.mobilebilling.daoservices.PostPaidAccountDAO;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.services.BillingServicesImpl;
@RunWith(EasyMockRunner.class)
public class BillingServicesTest {
	
	@Mock
	BillingServiceDAO billingServiceDAOMock;
	@Mock
	CustomerDAO customerDAOMock;
	@Mock
	PlanDetailsDAO planDetailsDAOMock;
	@Mock
	PostPaidAccountDAO postPaidAccountDAOMock;
	@TestSubject
	BillingServices billingServices=new BillingServicesImpl();
	
	@BeforeClass
	public static void setUPTestEnv(){
	}
	@Before
	public void setUPMockDataForTwo(){
		System.out.println("setUpMockDataForTest()");
	}
	
	@Test(expected=CustomerDetailsNotFoundException.class)
	public void customerDetailsNotFound() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		billingServices.getCustomerDetails(20020);
	}
	@Test(expected=PostpaidAccountNotFoundException.class)
	public void postpaidAccountNotFound() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		billingServices.getPostPaidAccountDetails(20020, 999999999);
	}
	@Test(expected=PlanDetailsNotFoundException.class)
	public void planDetailsNotFound() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException  {
		billingServices.getCustomerPostPaidAccountPlanDetails(20020, 999999999);
	}
	@Test(expected=BillDetailsNotFoundException.class)
	public void billDetailsNotFound() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, BillingServicesDownException {
		billingServices.getMobileBillDetails(20020,999999999, "October");
	}
	
	@After
	public void tearDownMockDataForTest(){
		System.out.println("tearDownMockDataForTest()");
	}
	@AfterClass
	public static void tearDownTestEnv(){
		
	}


	

}
