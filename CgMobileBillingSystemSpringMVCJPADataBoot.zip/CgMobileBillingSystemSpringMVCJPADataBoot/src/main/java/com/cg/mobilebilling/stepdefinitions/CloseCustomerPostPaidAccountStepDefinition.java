package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.CloseCustomerPostPaidAccountPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CloseCustomerPostPaidAccountStepDefinition {
	private WebDriver driver;
	private CloseCustomerPostPaidAccountPage closeCustomerPostPaidAccountPage;
	@Given("^User is on closeCustomerPostPaidAccountPage Page$")
	public void user_is_on_closeCustomerPostPaidAccountPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\nitika\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/closeCustomerPostPaidAccount");
		closeCustomerPostPaidAccountPage=PageFactory.initElements(driver, CloseCustomerPostPaidAccountPage.class);
	}

	@When("^User enter his correct credentials and click on delete postpaid account button$")
	public void user_enter_his_correct_credentials_and_click_on_delete_postpaid_account_button() throws Throwable {
	   closeCustomerPostPaidAccountPage.setCustomerID("20021");
	   closeCustomerPostPaidAccountPage.setMobileNo("999999999");
	   closeCustomerPostPaidAccountPage.clickSignIn();
	}

	@Then("^User is redirected to closeCustomerPostPaidAccountPage page and message gets displayed$")
	public void user_is_redirected_to_closeCustomerPostPaidAccountPage_page_and_message_gets_displayed() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Close Customer PostPaid Account";
		Assert.assertEquals(expectedTitle, actualTitle);
	}



}
