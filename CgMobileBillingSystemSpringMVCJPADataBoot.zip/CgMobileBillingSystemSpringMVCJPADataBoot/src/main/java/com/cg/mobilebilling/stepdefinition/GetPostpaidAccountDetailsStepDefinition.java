package com.cg.mobilebilling.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.GetPostpaidAccountDetailsPage;
import com.cg.mobilebilling.pagebeans.OpenPostpaidMobileAccount;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetPostpaidAccountDetailsStepDefinition {
	private WebDriver driver;
	private GetPostpaidAccountDetailsPage getPostpaidAccountDetailsPage;
	
	@Given("^User is on getPostPaidAccountDetailsPage Page$")
	public void user_is_on_getPostPaidAccountDetailsPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\nitika\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/");
		getPostpaidAccountDetailsPage=PageFactory.initElements(driver, GetPostpaidAccountDetailsPage.class);
	}

	@When("^User enter his correct credentials and click on get postpaid account details button$")
	public void user_enter_his_correct_credentials_and_click_on_get_postpaid_account_details_button() throws Throwable {
		getPostpaidAccountDetailsPage.setCustomerID("20001");
		getPostpaidAccountDetailsPage.setMobileNo("999999999");
		getPostpaidAccountDetailsPage.clickSignIn();
	  
	}

	@Then("^User is redirected to getPostPaidAccountDetailsPage page and details gets displayed$")
	public void user_is_redirected_to_getPostPaidAccountDetailsPage_page_and_details_gets_displayed() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Get postpaid account details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}


}
