package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class GetCustomerPostpaidAccountPlanDetailsPage {
	@FindBy(how=How.XPATH,xpath="//*[@id=\"plan\"]/table/tbody/tr[1]/td[2]/input")
	private WebElement customerID;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"plan\"]/table/tbody/tr[2]/td[2]/input")
	private WebElement mobileNo;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"plan\"]/input")
	private WebElement button1;
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/div/form/input")
	private WebElement button2;
	
	public String getCustomerID() {
		return customerID.getAttribute("value");
	}
	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);
	}
	public String getMobileNo() {
		return mobileNo.getAttribute("value");
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}
	
	public void clickSignIn() {
		button1.click();
	}	
	public void clickHome() {
		button2.click();
	}	
}
