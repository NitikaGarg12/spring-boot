package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class GetCustomerPostpaidAccountPlanDetailsStepDefinition {
	

}
