package com.cg.mobilebilling.pagebeans;

public class GetAllCustomerDetails {

}
