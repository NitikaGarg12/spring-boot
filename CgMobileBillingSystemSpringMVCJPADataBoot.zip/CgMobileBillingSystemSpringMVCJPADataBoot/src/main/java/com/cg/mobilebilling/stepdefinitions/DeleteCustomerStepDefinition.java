/*package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.ChangePlanPage;
import com.cg.mobilebilling.pagebeans.DeleteCustomerPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DeleteCustomerStepDefinition {
	private WebDriver driver;
	private DeleteCustomerPage deleteCustomerPage;
	@Given("^User is on deleteCustomerPage Page$")
	public void user_is_on_deleteCustomerPage_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\nitika\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/deleteCustomer");
		deleteCustomerPage=PageFactory.initElements(driver, DeleteCustomerPage.class);
	}

	@When("^User enter his correct credentials and click on delete customer button$")
	public void user_enter_his_correct_credentials_and_click_on_delete_customer_button() throws Throwable {
	  deleteCustomerPage.setCustomerID("20042");
	  deleteCustomerPage.clickSignIn();
	}

	@Then("^User is redirected to deleteCustomerPage page and message gets displayed$")
	public void user_is_redirected_to_deleteCustomerPage_page_and_message_gets_displayed() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Delete Customer";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

}
*/