package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class GenerateMonthlyMobileBillPage {
	@FindBy(how=How.XPATH,xpath="//*[@id=\"bill\"]/table/tbody/tr[1]/td[2]/input")
	private WebElement customerID;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"bill\"]/table/tbody/tr[2]/td[2]/input")
	private WebElement mobileNo;
	@FindBy(how=How.ID,id="noOfLocalSMS")
	private WebElement noOfLocalSMS;
	@FindBy(how=How.ID,id="noOfStdSMS")
	private WebElement noOfStdSMS;
	@FindBy(how=How.ID,id="noOfLocalCalls")
	private WebElement noOfLocalCalls;
	@FindBy(how=How.ID,id="noOfStdCalls")
	private WebElement noOfStdCalls;
	@FindBy(how=How.ID,id="internetDataUsageUnits")
	private WebElement internetDataUsageUnits;
	@FindBy(how=How.ID,id="billMonth")
	private WebElement billMonth;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"bill\"]/input")
	private WebElement button1;
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/div/form/input")
	private WebElement button2;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]")
	private WebElement actualMessage;
	public GenerateMonthlyMobileBillPage() {}
	public String getCustomerID() {
		return customerID.getAttribute("value");
	}
	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);
	}
	public String getMobileNo() {
		return mobileNo.getAttribute("value");
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo.clear();
		this.mobileNo.sendKeys(mobileNo);
	}
	public String getNoOfLocalSMS() {
		return noOfLocalSMS.getAttribute("value");
	}
	public void setNoOfLocalSMS(String noOfLocalSMS) {
		this.noOfLocalSMS.clear();
		this.noOfLocalSMS.sendKeys(noOfLocalSMS);
	}
	public String getNoOfStdSMS() {
		return noOfStdSMS.getAttribute("value");
	}
	public void setNoOfStdSMS(String noOfStdSMS) {
		this.noOfStdSMS.clear();
		this.noOfStdSMS.sendKeys(noOfStdSMS);
	}
	public String getNoOfLocalCalls() {
		return noOfLocalCalls.getAttribute("value");
	}
	public void setNoOfLocalCalls(String noOfLocalCalls) {
		this.noOfLocalCalls.clear();
		this.noOfLocalCalls.sendKeys(noOfLocalCalls);
	}
	public String getNoOfStdCalls() {
		return noOfStdCalls.getAttribute("value");
	}
	public void setNoOfStdCalls(String noOfStdCalls) {
		this.noOfStdCalls.clear();
		this.noOfStdCalls.sendKeys(noOfStdCalls);
	}
	public String getInternetDataUsageUnits() {
		return internetDataUsageUnits.getAttribute("value");
	}
	public void setInternetDataUsageUnits(String internetDataUsageUnits) {
		this.internetDataUsageUnits.clear();
		this.internetDataUsageUnits.sendKeys(internetDataUsageUnits);
	}
	public String getBillMonth() {
		return billMonth.getAttribute("value");
	}
	public void setBillMonth(String billMonth) {
		this.billMonth.clear();
		this.billMonth.sendKeys(billMonth);
	}
	public String getActualMessage() {
		return actualMessage.getText();
	}

	public void clickSignIn() {
		button1.submit();
	}	
	public void clickHome() {
		button2.click();
	}	
	
	
}
