package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class IndexPage {
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[1]/td[2]/a")
	private WebElement link1;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[2]/td[2]/a")
	private WebElement link2;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[3]/td[2]/a")
	private WebElement link3;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[4]/td[2]/a")
	private WebElement link4;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[5]/td[2]/a")
	private WebElement link5;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[6]/td[2]/a")
	private WebElement link6;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[7]/td[2]/a")
	private WebElement link7;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[8]/td[2]/a")
	private WebElement link8;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[1]/td[2]/a")
	private WebElement link9;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[2]/td[2]/a")
	private WebElement link10;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[3]/td[2]/a")
	private WebElement link11;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[4]/td[2]/a")
	private WebElement link12;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[5]/td[2]/a")
	private WebElement link13;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[6]/td[2]/a")
	private WebElement link14;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[7]/td[2]/a")
	private WebElement link15;
	public IndexPage() {}
	public void clickSignIn() {
		link1.click();
	}	
	
	
}
