package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class IndexPage {
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[1]/td[2]/a")
	private WebElement registration;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[2]/td[2]/a")
	private WebElement planAllDetails;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[3]/td[2]/a")
	private WebElement openPostpaidMobileAccount;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[4]/td[2]/a")
	private WebElement generateMonthlyMobileBill;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[5]/td[2]/a")
	private WebElement getCustomerDetails;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[6]/td[2]/a")
	private WebElement allCustomerDetails;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[7]/td[2]/a")
	private WebElement getPostPaidAccountDetails;
	@FindBy(how=How.XPATH,xpath="/html/body/div[2]/form/table/tbody/tr[8]/td[2]/a")
	private WebElement getCustomerAllPostpaidAccountsDetails;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[1]/td[2]/a")
	private WebElement getMobileBillDetails;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[2]/td[2]/a")
	private WebElement getCustomerPostPaidAccountAllBillDetails;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[3]/td[2]/a")
	private WebElement changePlan;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[4]/td[2]/a")
	private WebElement deleteCustomer;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[5]/td[2]/a")
	private WebElement closeCustomerPostPaidAccount;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[6]/td[2]/a")
	private WebElement getCustomerPostPaidAccountPlanDetails;
	@FindBy(how=How.XPATH,xpath="/html/body/div[3]/table/tbody/tr[7]/td[2]/a")
	private WebElement addPlans;
	
	public IndexPage() {
		super();
	}
	public void registration() {
		registration.click();
	}	
	public void planAllDetails() {
		planAllDetails.click();
	}	
	public void openPostpaidMobileAccount() {
		openPostpaidMobileAccount.click();
	}	
	public void generateMonthlyMobileBill() {
		generateMonthlyMobileBill.click();
	}	
	public void getCustomerDetails() {
		getCustomerDetails.click();
	}	
	public void allCustomerDetails() {
		allCustomerDetails.click();
	}	
	public void getPostPaidAccountDetails() {
		getPostPaidAccountDetails.click();
	}	
	public void getCustomerAllPostpaidAccountsDetails() {
		getCustomerAllPostpaidAccountsDetails.click();
	}	
	public void getMobileBillDetails() {
		getMobileBillDetails.click();
	}	
	public void getCustomerPostPaidAccountAllBillDetails() {
		getCustomerPostPaidAccountAllBillDetails.click();
	}	
	public void changePlan() {
		changePlan.click();
	}	
	public void deleteCustomer() {
		deleteCustomer.click();
	}	
	public void closeCustomerPostPaidAccount() {
		closeCustomerPostPaidAccount.click();
	}	
	public void getCustomerPostPaidAccountPlanDetails() {
		getCustomerPostPaidAccountPlanDetails.click();
	}	
	public void addPlans() {
		addPlans.click();
	}	
	
	
}
