package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class GetCustomerDetails {
	@FindBy(how=How.ID,id="customerID")
	private WebElement customerID;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"customer\"]/input")
	private WebElement button1;
	@FindBy(how=How.XPATH,xpath="/html/body/div[1]/div/form/input")
	private WebElement button2;
	
	public GetCustomerDetails() {}
	public String getCustomerID() {
		return customerID.getAttribute("value");
	}
	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);
	}
	public void clickSignIn() {
		button1.click();
	}	
	public void clickHome() {
		button2.click();
	}	
}
