package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.pagebeans.LoginPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GithubLoginStepDefinition {
	private WebDriver driver;
	private LoginPage loginPage;
	/*@Before(order=1)
	public void setUpStepEnv1() {
	}*/
	@Given("^User is on Github LoginPage$")
	public void user_is_on_Github_LoginPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\nitika\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://github.com/login");
		loginPage=PageFactory.initElements(driver, LoginPage.class);
	}

	@When("^User enter his correct details$")
	public void user_enter_his_correct_details() throws Throwable {
		loginPage.setUsername("nini.garg@gmail.com");
		loginPage.setPassword("nitika@12");
		loginPage.clickSignIn();
	}
	@Then("^User is redirected to his home page$")
	public void user_is_redirected_to_his_home_page() throws Throwable {
		/*String actualTitle=driver.getTitle();
		String expectedTitle="GitHub";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();*/
		loginPage.getUsername();
		loginPage.getPassword();
		loginPage.clickSignIn();
		driver.close();
	}
	@When("^User enter incorrect  details$")
	public void user_enter_incorrect_details() throws Throwable {
		loginPage.setUsername("nini.garg@gmail.com");
		loginPage.setPassword("nitika12");
		loginPage.clickSignIn();
	}
	@Then("^'Incorrect username or password'\\. Message should display$")
	public void incorrect_username_or_password_Message_should_display() throws Throwable {
		loginPage.getUsername();
		loginPage.getPassword();
		loginPage.clickSignIn();
		driver.close();
	}






}
