package com.cg.project.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GmailLoginStepDefinition {
	@Given("^User is on Gmail LoginPage$")
	public void user_is_on_Gmail_LoginPage() throws Throwable {
	 
	}

	@When("^User enter his correct credentials$")
	public void user_enter_his_correct_credentials() throws Throwable {
	  
	}

	@Then("^User is redirected to his Gmail account$")
	public void user_is_redirected_to_his_Gmail_account() throws Throwable {
	    
	}
}
